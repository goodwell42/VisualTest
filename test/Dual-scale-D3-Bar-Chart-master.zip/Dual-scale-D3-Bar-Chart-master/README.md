Dual-scale-D3-Bar-Chart
========================

![Preview](preview/thumbnail.png)

This is a demo for creating dual-scaled bar charts using D3.js

I came across this task when I was working on a simple HTML project. As I googled around and, unfortunately, could not find any example, I decided to do it myself.

Please bear in mind that I am new to D3.js and this is actually my first time using it. I had heard of D3.js but never used it.

Hope that this could be of use to someone. All suggestions for improvement are welcome.

Note: since d3.js uses ajax to load tsv files, the files contained in the src folder cannot be run in a browser using file:///. Execute the following command under the src directory to create a HTTP server.

    python -m SimpleHTTPServer

Use the following URL to access index.html

    http://localhost:8000/index.html
